## This is a Mod Pack with 80 other dependent Mods for the Server 2 Brothers Gaming.
 
+ This Modpack is for the most current version of Mistlands.

---
+ This is currently a private server
---
### V1.0.4

   - Updated current mods and added more mods to the modpack.

### V1.0.3

   - Switched certain mods due to incompatibily issues.

### V1.0.2

   - Found an incompatibily with one of the mods and had to remove it.

### V1.0.1

   - Updated current mods, added 4 other mods to the modpack and included a config file with server configs.

### V1.0.0

   - Initial Release